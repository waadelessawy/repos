SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_EmailOAuthCredentials](
	[EmailOAuthCredentialsID] [int] IDENTITY(1,1) NOT NULL,
	[EmailOAuthCredentialsDisplayName] [nvarchar](200) NOT NULL,
	[EmailOAuthCredentialsClientID] [nvarchar](max) NOT NULL,
	[EmailOAuthCredentialsClientSecret] [nvarchar](max) NOT NULL,
	[EmailOAuthCredentialsTenantID] [nvarchar](200) NULL,
	[EmailOAuthCredentialsProviderAssemblyName] [nvarchar](200) NOT NULL,
	[EmailOAuthCredentialsProviderClass] [nvarchar](200) NOT NULL,
	[EmailOAuthCredentialsAccessToken] [nvarchar](max) NULL,
	[EmailOAuthCredentialsTokenExpirationUtc] [datetime2](7) NULL,
	[EmailOAuthCredentialsRefreshToken] [nvarchar](max) NULL,
	[EmailOAuthCredentialsGuid] [uniqueidentifier] NOT NULL,
	[EmailOAuthCredentialsLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_EmailOAuthCredentials] PRIMARY KEY CLUSTERED 
(
	[EmailOAuthCredentialsID] ASC
)
)
GO
ALTER TABLE [dbo].[CMS_EmailOAuthCredentials] ADD  CONSTRAINT [DEFAULT_CMS_EmailOAuthCredentials_EmailOAuthCredentialsDisplayName]  DEFAULT (N'') FOR [EmailOAuthCredentialsDisplayName]
GO
ALTER TABLE [dbo].[CMS_EmailOAuthCredentials] ADD  CONSTRAINT [DEFAULT_CMS_EmailOAuthCredentials_EmailOAuthCredentialsClientID]  DEFAULT (N'') FOR [EmailOAuthCredentialsClientID]
GO
ALTER TABLE [dbo].[CMS_EmailOAuthCredentials] ADD  CONSTRAINT [DEFAULT_CMS_EmailOAuthCredentials_EmailOAuthCredentialsClientSecret]  DEFAULT (N'') FOR [EmailOAuthCredentialsClientSecret]
GO
ALTER TABLE [dbo].[CMS_EmailOAuthCredentials] ADD  CONSTRAINT [DEFAULT_CMS_EmailOAuthCredentials_EmailOAuthCredentialsProviderAssemblyName]  DEFAULT (N'') FOR [EmailOAuthCredentialsProviderAssemblyName]
GO
ALTER TABLE [dbo].[CMS_EmailOAuthCredentials] ADD  CONSTRAINT [DEFAULT_CMS_EmailOAuthCredentials_EmailOAuthCredentialsProviderClass]  DEFAULT (N'') FOR [EmailOAuthCredentialsProviderClass]
GO
ALTER TABLE [dbo].[CMS_EmailOAuthCredentials] ADD  CONSTRAINT [DEFAULT_CMS_EmailOAuthCredentials_EmailOAuthCredentialsGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [EmailOAuthCredentialsGuid]
GO
ALTER TABLE [dbo].[CMS_EmailOAuthCredentials] ADD  CONSTRAINT [DEFAULT_CMS_EmailOAuthCredentials_EmailOAuthCredentialsLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [EmailOAuthCredentialsLastModified]
GO
