SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_PageUrlPath_UpdateUrlPaths_Internal]
	@OriginalUrlPath NVARCHAR(2000),
	@NewUrlPath NVARCHAR(2000),
	@CultureCode NVARCHAR(50),
	@OriginalSiteID INT,
	@NewSiteID INT,
	@LastModified DATETIME,
	@StoreFormerUrls BIT
AS
BEGIN
	DECLARE @NewPaths TABLE(
		[PathID] INT NOT NULL, 
		[OriginalPath] NVARCHAR(2000) NOT NULL, 
		[OriginalPathHash] NVARCHAR(64) NOT NULL,
		[NewPath] NVARCHAR(2000) NOT NULL, 
		[NewPathHash] NVARCHAR(64) NOT NULL)
			
	INSERT INTO @NewPaths 
		SELECT 
			[PageUrlPathID], 
			[PageUrlPathUrlPath],
			[PageUrlPathUrlPathHash],
			@NewUrlPath, 
			CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@NewUrlPath)), 2)
		FROM [CMS_PageUrlPath] 
		WHERE [PageUrlPathUrlPathHash] = CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@OriginalUrlPath)), 2) AND [PageUrlPathCulture] = @CultureCode AND [PageUrlPathSiteID] = @OriginalSiteID
		UNION
		SELECT 
			[PageUrlPathID], 
			[PageUrlPathUrlPath],
			[PageUrlPathUrlPathHash],
			@NewUrlPath + SUBSTRING([PageUrlPathUrlPath], LEN(@OriginalUrlPath) + 1, LEN([PageUrlPathUrlPath])), 
			CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@NewUrlPath + SUBSTRING([PageUrlPathUrlPath], LEN(@OriginalUrlPath) + 1, LEN([PageUrlPathUrlPath])))), 2)
		FROM [CMS_PageUrlPath] 
		WHERE [PageUrlPathUrlPath] LIKE @OriginalUrlPath + '/%' AND [PageUrlPathCulture] = @CultureCode AND [PageUrlPathSiteID] = @OriginalSiteID

	UPDATE [CMS_PageUrlPath]
	SET 
		[PageUrlPathUrlPath] = [NP].[NewPath],
		[PageUrlPathUrlPathHash] = [NP].[NewPathHash],
		[PageUrlPathLastModified] = @LastModified,
		[PageUrlPathSiteID] = @NewSiteID
	FROM @NewPaths as [NP]
	WHERE [CMS_PageUrlPath].[PageUrlPathID] = [NP].[PathID]

	IF (@StoreFormerUrls = 1)
	BEGIN
		DELETE FROM [CMS_PageFormerUrlPath]
		WHERE [PageFormerUrlPathCulture] = @CultureCode AND [PageFormerUrlPathSiteID] = @OriginalSiteID AND [PageFormerUrlPathUrlPathHash] IN (SELECT [OriginalPathHash] FROM @NewPaths)

		INSERT INTO [CMS_PageFormerUrlPath]
		SELECT 
			[NewPath].[OriginalPath] AS [PageFormerUrlPathUrlPath], 
			[NewPath].[OriginalPathHash] AS [PageFormerUrlPathUrlPathHash],
			[Original].[PageUrlPathCulture] AS [PageFormerUrlPathCulture],
			[Original].[PageUrlPathNodeID] AS [PageFormerUrlPathNodeID],
			@OriginalSiteID AS [PageFormerUrlPathSiteID],
			@LastModified AS [PageFormerUrlPathLastModified]
		FROM [CMS_PageUrlPath] as [Original]
		INNER JOIN @NewPaths as [NewPath] ON [Original].[PageUrlPathID] = [NewPath].[PathID]
	END	
END
GO
