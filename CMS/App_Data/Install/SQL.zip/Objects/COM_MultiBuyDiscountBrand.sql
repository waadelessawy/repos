SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_MultiBuyDiscountBrand](
	[MultiBuyDiscountID] [int] NOT NULL,
	[BrandID] [int] NOT NULL,
	[BrandIncluded] [bit] NOT NULL,
 CONSTRAINT [PK_COM_MultiBuyDiscountBrand] PRIMARY KEY CLUSTERED 
(
	[MultiBuyDiscountID] ASC,
	[BrandID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_MultiBuyDiscountBrand_BrandID] ON [dbo].[COM_MultiBuyDiscountBrand]
(
	[BrandID] ASC
)
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountBrand] ADD  CONSTRAINT [DEFAULT_COM_MultiBuyDiscountBrand_BrandID]  DEFAULT ((0)) FOR [BrandID]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountBrand] ADD  CONSTRAINT [DEFAULT_COM_MultiBuyDiscountBrand_BrandIncluded]  DEFAULT ((1)) FOR [BrandIncluded]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountBrand]  WITH CHECK ADD  CONSTRAINT [FK_COM_MultiBuyDiscountBrand_BrandID_COM_Brand] FOREIGN KEY([BrandID])
REFERENCES [dbo].[COM_Brand] ([BrandID])
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountBrand] CHECK CONSTRAINT [FK_COM_MultiBuyDiscountBrand_BrandID_COM_Brand]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountBrand]  WITH CHECK ADD  CONSTRAINT [FK_COM_MultiBuyDiscountBrand_MultiBuyDiscountID_COM_MultiBuyDiscount] FOREIGN KEY([MultiBuyDiscountID])
REFERENCES [dbo].[COM_MultiBuyDiscount] ([MultiBuyDiscountID])
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountBrand] CHECK CONSTRAINT [FK_COM_MultiBuyDiscountBrand_MultiBuyDiscountID_COM_MultiBuyDiscount]
GO
