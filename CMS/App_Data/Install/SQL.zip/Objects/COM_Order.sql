SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_Order](
	[OrderID] [int] IDENTITY(1,1) NOT NULL,
	[OrderShippingOptionID] [int] NULL,
	[OrderTotalShipping] [decimal](18, 9) NULL,
	[OrderTotalPrice] [decimal](18, 9) NOT NULL,
	[OrderTotalTax] [decimal](18, 9) NOT NULL,
	[OrderDate] [datetime2](7) NOT NULL,
	[OrderStatusID] [int] NULL,
	[OrderCurrencyID] [int] NULL,
	[OrderCustomerID] [int] NOT NULL,
	[OrderCreatedByUserID] [int] NULL,
	[OrderNote] [nvarchar](max) NULL,
	[OrderSiteID] [int] NOT NULL,
	[OrderPaymentOptionID] [int] NULL,
	[OrderInvoice] [nvarchar](max) NULL,
	[OrderInvoiceNumber] [nvarchar](200) NULL,
	[OrderTrackingNumber] [nvarchar](100) NULL,
	[OrderCustomData] [nvarchar](max) NULL,
	[OrderPaymentResult] [nvarchar](max) NULL,
	[OrderGUID] [uniqueidentifier] NOT NULL,
	[OrderLastModified] [datetime2](7) NOT NULL,
	[OrderTotalPriceInMainCurrency] [decimal](18, 9) NULL,
	[OrderIsPaid] [bit] NULL,
	[OrderCulture] [nvarchar](50) NULL,
	[OrderDiscounts] [nvarchar](max) NULL,
	[OrderGrandTotal] [decimal](18, 9) NOT NULL,
	[OrderGrandTotalInMainCurrency] [decimal](18, 9) NULL,
	[OrderOtherPayments] [nvarchar](max) NULL,
	[OrderTaxSummary] [nvarchar](max) NULL,
	[OrderCouponCodes] [nvarchar](max) NULL,
 CONSTRAINT [PK_COM_Order] PRIMARY KEY CLUSTERED 
(
	[OrderID] ASC
)
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Order_OrderCreatedByUserID] ON [dbo].[COM_Order]
(
	[OrderCreatedByUserID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Order_OrderCurrencyID] ON [dbo].[COM_Order]
(
	[OrderCurrencyID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Order_OrderCustomerID] ON [dbo].[COM_Order]
(
	[OrderCustomerID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Order_OrderPaymentOptionID] ON [dbo].[COM_Order]
(
	[OrderPaymentOptionID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Order_OrderShippingOptionID] ON [dbo].[COM_Order]
(
	[OrderShippingOptionID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Order_OrderSiteID_OrderDate] ON [dbo].[COM_Order]
(
	[OrderSiteID] ASC,
	[OrderDate] DESC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Order_OrderStatusID] ON [dbo].[COM_Order]
(
	[OrderStatusID] ASC
)
GO
ALTER TABLE [dbo].[COM_Order] ADD  CONSTRAINT [DEFAULT_COM_Order_OrderTotalPrice]  DEFAULT ((0)) FOR [OrderTotalPrice]
GO
ALTER TABLE [dbo].[COM_Order] ADD  CONSTRAINT [DEFAULT_COM_Order_OrderTotalTax]  DEFAULT ((0)) FOR [OrderTotalTax]
GO
ALTER TABLE [dbo].[COM_Order] ADD  CONSTRAINT [DEFAULT_COM_Order_OrderGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [OrderGUID]
GO
ALTER TABLE [dbo].[COM_Order] ADD  CONSTRAINT [DEFAULT_COM_Order_OrderGrandTotal]  DEFAULT ((0)) FOR [OrderGrandTotal]
GO
ALTER TABLE [dbo].[COM_Order]  WITH CHECK ADD  CONSTRAINT [FK_COM_Order_OrderCreatedByUserID_CMS_User] FOREIGN KEY([OrderCreatedByUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[COM_Order] CHECK CONSTRAINT [FK_COM_Order_OrderCreatedByUserID_CMS_User]
GO
ALTER TABLE [dbo].[COM_Order]  WITH CHECK ADD  CONSTRAINT [FK_COM_Order_OrderCurrencyID_COM_Currency] FOREIGN KEY([OrderCurrencyID])
REFERENCES [dbo].[COM_Currency] ([CurrencyID])
GO
ALTER TABLE [dbo].[COM_Order] CHECK CONSTRAINT [FK_COM_Order_OrderCurrencyID_COM_Currency]
GO
ALTER TABLE [dbo].[COM_Order]  WITH CHECK ADD  CONSTRAINT [FK_COM_Order_OrderCustomerID_COM_Customer] FOREIGN KEY([OrderCustomerID])
REFERENCES [dbo].[COM_Customer] ([CustomerID])
GO
ALTER TABLE [dbo].[COM_Order] CHECK CONSTRAINT [FK_COM_Order_OrderCustomerID_COM_Customer]
GO
ALTER TABLE [dbo].[COM_Order]  WITH CHECK ADD  CONSTRAINT [FK_COM_Order_OrderPaymentOptionID_COM_PaymentOption] FOREIGN KEY([OrderPaymentOptionID])
REFERENCES [dbo].[COM_PaymentOption] ([PaymentOptionID])
GO
ALTER TABLE [dbo].[COM_Order] CHECK CONSTRAINT [FK_COM_Order_OrderPaymentOptionID_COM_PaymentOption]
GO
ALTER TABLE [dbo].[COM_Order]  WITH CHECK ADD  CONSTRAINT [FK_COM_Order_OrderShippingOptionID_COM_ShippingOption] FOREIGN KEY([OrderShippingOptionID])
REFERENCES [dbo].[COM_ShippingOption] ([ShippingOptionID])
GO
ALTER TABLE [dbo].[COM_Order] CHECK CONSTRAINT [FK_COM_Order_OrderShippingOptionID_COM_ShippingOption]
GO
ALTER TABLE [dbo].[COM_Order]  WITH CHECK ADD  CONSTRAINT [FK_COM_Order_OrderSiteID_CMS_Site] FOREIGN KEY([OrderSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[COM_Order] CHECK CONSTRAINT [FK_COM_Order_OrderSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[COM_Order]  WITH CHECK ADD  CONSTRAINT [FK_COM_Order_OrderStatusID_COM_Status] FOREIGN KEY([OrderStatusID])
REFERENCES [dbo].[COM_OrderStatus] ([StatusID])
GO
ALTER TABLE [dbo].[COM_Order] CHECK CONSTRAINT [FK_COM_Order_OrderStatusID_COM_Status]
GO
